-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: k6a104.p.ssafy.io    Database: neulbom
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `career`
--

DROP TABLE IF EXISTS `career`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `career` (
  `career_seq` bigint NOT NULL AUTO_INCREMENT,
  `user_seq` int NOT NULL,
  `career_content` varchar(100) NOT NULL,
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_email` varchar(30) NOT NULL,
  `reg_dt` varchar(20) NOT NULL,
  `mod_email` varchar(30) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  PRIMARY KEY (`career_seq`),
  UNIQUE KEY `career_seq_UNIQUE` (`career_seq`),
  KEY `career_expert_fk_idx` (`user_seq`),
  CONSTRAINT `career_expert_fk` FOREIGN KEY (`user_seq`) REFERENCES `expert` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career`
--

LOCK TABLES `career` WRITE;
/*!40000 ALTER TABLE `career` DISABLE KEYS */;
INSERT INTO `career` VALUES (1,3,'서울대병원 근무','n','expert@gmail.com','2022-04-26 01:43:28','expert@gmail.com','2022-04-26 01:43:28'),(2,3,'율제병원 근무','n','expert@gmail.com','2022-04-26 01:43:28','expert@gmail.com','2022-04-26 01:43:28'),(3,4,'중구 보건소 근무','n','expert2@gmail.com','2022-04-26 01:43:28','expert2@gmail.com','2022-04-26 01:43:28'),(4,7,'string','n','string','2022-04-27 11:23:26','string','2022-04-27 11:23:26'),(5,15,'싸피 병원 수정 테스트','y','sdi1358_@naver.com','2022-04-27 15:09:05','sdi1358_@naver.com','2022-04-28 17:47:02'),(6,15,'싸피보건소 근무','y','sdi1358_@naver.com','2022-04-27 15:09:05','sdi1358_@naver.com','2022-04-27 15:09:05'),(7,15,'새 이력 추가','y','sdi1358_@naver.com','2022-04-28 17:42:15','sdi1358_@naver.com','2022-04-28 17:42:15'),(8,15,'새 이력 추가','y','sdi1358_@naver.com','2022-04-28 17:47:02','sdi1358_@naver.com','2022-04-28 17:47:02'),(9,15,'새 이력 추가','y','sdi1358_@naver.com','2022-04-28 17:48:26','sdi1358_@naver.com','2022-04-28 17:48:26'),(10,15,'이력 추가 테스트','y','sdi1358_@naver.com','2022-04-28 17:50:04','sdi1358_@naver.com','2022-04-28 17:50:04'),(11,15,'싸피 병원 근무','y','sdi1358_@naver.com','2022-04-29 12:13:00','sdi1358_@naver.com','2022-04-29 12:13:00'),(12,15,'싸피 보건소 근무','y','sdi1358_@naver.com','2022-04-29 12:13:00','sdi1358_@naver.com','2022-04-29 12:13:00'),(13,17,'싸피 보건소','n','freessafy104@gmail.com','2022-05-04 15:36:03','freessafy104@gmail.com','2022-05-04 15:36:03'),(14,17,'싸피 병원','n','freessafy104@gmail.com','2022-05-04 15:36:03','freessafy104@gmail.com','2022-05-04 15:36:03'),(15,26,'싸피 보건소','n','jung55120@naver.com','2022-05-13 10:39:34','jung55120@naver.com','2022-05-13 10:39:34'),(16,26,'싸피 병원','y','jung55120@naver.com','2022-05-13 10:39:34','jung55120@naver.com','2022-05-13 10:39:34'),(17,26,'싸피 병원 근무','n','jung55120@naver.com','2022-05-16 17:57:39','jung55120@naver.com','2022-05-16 17:57:39'),(18,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 17:57:39','jung55120@naver.com','2022-05-16 17:57:39'),(19,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-16 18:02:27','jung55120@naver.com','2022-05-16 18:02:27'),(20,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 18:02:27','jung55120@naver.com','2022-05-16 18:02:27'),(21,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-16 18:02:38','jung55120@naver.com','2022-05-16 18:02:38'),(22,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 18:02:38','jung55120@naver.com','2022-05-16 18:02:38'),(23,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-16 18:04:27','jung55120@naver.com','2022-05-16 18:04:27'),(24,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 18:04:27','jung55120@naver.com','2022-05-16 18:04:27'),(25,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-16 18:04:48','jung55120@naver.com','2022-05-16 18:04:48'),(26,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 18:04:48','jung55120@naver.com','2022-05-16 18:04:48'),(27,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-16 18:06:06','jung55120@naver.com','2022-05-16 18:06:06'),(28,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 18:06:06','jung55120@naver.com','2022-05-16 18:06:06'),(29,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-16 18:07:24','jung55120@naver.com','2022-05-16 18:07:24'),(30,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 18:07:24','jung55120@naver.com','2022-05-16 18:07:24'),(31,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-16 18:08:46','jung55120@naver.com','2022-05-16 18:08:46'),(32,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 18:08:46','jung55120@naver.com','2022-05-16 18:08:46'),(33,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-16 18:09:15','jung55120@naver.com','2022-05-16 18:09:15'),(34,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 18:09:15','jung55120@naver.com','2022-05-16 18:09:15'),(35,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-16 18:09:32','jung55120@naver.com','2022-05-16 18:09:32'),(36,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 18:09:32','jung55120@naver.com','2022-05-16 18:09:32'),(37,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-16 18:09:50','jung55120@naver.com','2022-05-16 18:09:50'),(38,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-16 18:09:50','jung55120@naver.com','2022-05-16 18:09:50'),(39,26,'싸피 병원 근무무','n','jung55120@naver.com','2022-05-17 10:28:46','jung55120@naver.com','2022-05-17 10:28:46'),(40,26,'싸피 보건소 근무','n','jung55120@naver.com','2022-05-17 10:28:46','jung55120@naver.com','2022-05-17 10:28:46'),(41,26,'ggdd','n','jung55120@naver.com','2022-05-17 11:35:04','jung55120@naver.com','2022-05-17 11:35:04'),(42,27,'강남구 보건소','n','ssafy_gangnam@gmail.com','2022-05-19 10:55:40','ssafy_gangnam@gmail.com','2022-05-19 10:55:40'),(43,27,'강남구 보건소 근무','n','ssafy_gangnam@gmail.com','2022-05-19 11:02:11','ssafy_gangnam@gmail.com','2022-05-19 11:02:11'),(44,28,'전) 거대 병원 내과 진료부장','n','bloodpressure@gmail.com','2022-05-19 11:19:53','bloodpressure@gmail.com','2022-05-19 11:19:53'),(45,28,'전) 율제대학교 의과대학 내과 임상외래교수','n','bloodpressure@gmail.com','2022-05-19 11:19:53','bloodpressure@gmail.com','2022-05-19 11:19:53'),(46,28,'현) 율제 병원 성인병내과 부원장','n','bloodpressure@gmail.com','2022-05-19 11:21:51','bloodpressure@gmail.com','2022-05-19 11:21:51'),(47,28,'현) 율제 병원 진료과장','y','bloodpressure@gmail.com','2022-05-19 11:21:51','bloodpressure@gmail.com','2022-05-19 11:21:51'),(48,29,'전) 광희대학교 인턴수료','n','newheart@gmail.com','2022-05-19 11:30:05','newheart@gmail.com','2022-05-19 11:30:05'),(49,29,'현) 한세 병원 진료과장','n','newheart@gmail.com','2022-05-19 11:30:05','newheart@gmail.com','2022-05-19 11:30:05'),(50,29,'전) 광희대학 병원','y','newheart@gmail.com','2022-05-19 11:35:49','newheart@gmail.com','2022-05-19 11:35:49'),(51,29,'현) 한세 병원','y','newheart@gmail.com','2022-05-19 11:35:49','newheart@gmail.com','2022-05-19 11:35:49'),(52,30,'율제병원','y','nurse104@gmail.com','2022-05-19 11:41:27','nurse104@gmail.com','2022-05-19 11:41:27'),(53,30,'율제병원 수간호사','n','nurse104@gmail.com','2022-05-19 11:45:29','nurse104@gmail.com','2022-05-19 11:45:29'),(54,31,'JTBC 구내 식당 ','y','bobbob@gmail.com','2022-05-19 12:47:38','bobbob@gmail.com','2022-05-19 12:47:38'),(55,31,'JTBC 구내 식당 영양사','n','bobbob@gmail.com','2022-05-19 12:49:30','bobbob@gmail.com','2022-05-19 12:49:30'),(56,32,'닥터스 병원 간호사','y','doctors@gmail.com','2022-05-19 12:54:21','doctors@gmail.com','2022-05-19 12:54:21'),(57,32,'닥터스 병원 간호사','n','doctors@gmail.com','2022-05-19 12:56:09','doctors@gmail.com','2022-05-19 12:56:09');
/*!40000 ALTER TABLE `career` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-20 10:57:59
