-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: k6a104.p.ssafy.io    Database: neulbom
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blood_sugar`
--

DROP TABLE IF EXISTS `blood_sugar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blood_sugar` (
  `bs_seq` bigint NOT NULL AUTO_INCREMENT,
  `bs_code` varchar(45) NOT NULL,
  `user_seq` int NOT NULL,
  `bs_level` int NOT NULL,
  `bs_date` varchar(10) NOT NULL,
  `bs_time` varchar(5) NOT NULL,
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_email` varchar(30) NOT NULL,
  `reg_dt` varchar(20) NOT NULL,
  `mod_email` varchar(30) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  PRIMARY KEY (`bs_seq`),
  UNIQUE KEY `bs_seq_UNIQUE` (`bs_seq`),
  KEY `blood_sugar_member_fk_idx` (`user_seq`),
  KEY `blood_sugar_common_code_fk_idx` (`bs_code`),
  CONSTRAINT `blood_sugar_common_code_fk` FOREIGN KEY (`bs_code`) REFERENCES `common_code` (`code`),
  CONSTRAINT `blood_sugar_member_fk` FOREIGN KEY (`user_seq`) REFERENCES `member` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blood_sugar`
--

LOCK TABLES `blood_sugar` WRITE;
/*!40000 ALTER TABLE `blood_sugar` DISABLE KEYS */;
INSERT INTO `blood_sugar` VALUES (1,'beforeBreakfast',2,100,'2022-04-26','08:30','n','ssafy@gmail.com','2022-04-26 01:43:28','ssafy@gmail.com','2022-04-26 01:43:28'),(2,'afterBreakfast',2,130,'2022-04-26','09:30','n','ssafy@gmail.com','2022-04-26 01:43:28','ssafy@gmail.com','2022-04-26 01:43:28'),(3,'beforeLunch',2,90,'2022-04-26','11:30','n','ssafy@gmail.com','2022-04-27 15:43:36','ssafy@gmail.com','2022-04-27 15:43:36'),(4,'afterLunch',2,130,'2022-04-26','12:30','n','ssafy@gmail.com','2022-04-27 15:43:36','ssafy@gmail.com','2022-04-27 15:43:36'),(5,'beforeDinner',2,120,'2022-04-26','17:30','n','ssafy@gmail.com','2022-04-27 15:43:36','ssafy@gmail.com','2022-04-27 15:43:36'),(6,'afterDinner',2,150,'2022-04-26','19:00','n','ssafy@gmail.com','2022-04-27 15:43:36','ssafy@gmail.com','2022-04-27 15:43:36'),(7,'beforeBreakfast',2,90,'2022-04-27','08:30','n','ssafy@gmail.com','2022-04-27 15:44:44','ssafy@gmail.com','2022-04-27 15:44:44'),(8,'afterBreakfast',2,110,'2022-04-27','09:30','n','ssafy@gmail.com','2022-04-27 15:44:44','ssafy@gmail.com','2022-04-27 15:44:44'),(9,'beforeLunch',2,100,'2022-04-27','11:30','n','ssafy@gmail.com','2022-04-27 15:44:44','ssafy@gmail.com','2022-04-27 15:44:44'),(10,'afterLunch',2,140,'2022-04-27','12:30','n','ssafy@gmail.com','2022-04-27 15:44:44','ssafy@gmail.com','2022-04-27 15:44:44'),(11,'beforeDinner',2,115,'2022-04-27','17:30','n','ssafy@gmail.com','2022-04-27 15:44:44','ssafy@gmail.com','2022-04-27 15:44:44'),(12,'afterDinner',2,155,'2022-04-27','19:00','n','ssafy@gmail.com','2022-04-27 15:44:44','ssafy@gmail.com','2022-04-27 15:44:44'),(20,'afterBreakfast',14,100,'2022-04-28','16:42','y','string151','2022-05-04 15:08:33','string151','2022-05-04 15:08:33'),(21,'afterBreakfast',14,100,'2022-05-04','13:22','n','string151','2022-05-09 09:33:47','string151','2022-05-09 09:33:47'),(22,'afterLunch',14,100,'2022-05-12','04:12','n','string151','2022-05-12 13:13:21','string151','2022-05-12 13:13:21'),(23,'afterLunch',14,100,'2022-05-12','04:14','n','string151','2022-05-12 13:17:33','string151','2022-05-12 13:17:33'),(24,'afterDinner',14,100,'2022-05-12','04:14','n','string151','2022-05-12 13:17:42','string151','2022-05-12 13:17:42'),(25,'beforeLunch',14,100,'2022-05-11','14:58','n','string151','2022-05-12 14:59:10','string151','2022-05-12 14:59:10'),(26,'beforeLunch',14,100,'2022-05-02','14:58','n','string151','2022-05-12 14:59:34','string151','2022-05-12 14:59:34'),(27,'beforeLunch',14,100,'2022-05-12','15:04','n','string151','2022-05-12 15:05:29','string151','2022-05-12 15:05:29'),(28,'beforeBreakfast',23,100,'2022-05-12','15:05','n','ddd','2022-05-12 15:06:18','ddd','2022-05-12 15:06:18'),(29,'afterBreakfast',23,123,'2022-05-12','15:07','n','ddd','2022-05-12 15:08:25','ddd','2022-05-12 15:08:25'),(30,'afterLunch',23,13,'2022-05-12','16:57','n','ddd','2022-05-12 17:01:39','ddd','2022-05-12 17:01:39'),(31,'afterBreakfast',23,25,'2022-05-13','09:32','n','ddd','2022-05-13 09:34:31','ddd','2022-05-13 09:34:31'),(32,'afterLunch',23,123,'2022-05-13','10:17','n','ddd','2022-05-13 10:18:27','ddd','2022-05-13 10:18:27'),(33,'afterBreakfast',23,123,'2022-05-15','13:54','n','ddd','2022-05-15 13:55:31','ddd','2022-05-15 13:55:31'),(34,'beforeLunch',23,111,'2022-05-15','14:09','n','ddd','2022-05-15 14:09:27','ddd','2022-05-15 14:09:27'),(35,'beforeLunch',23,123,'2022-05-16','16:02','n','ddd','2022-05-16 16:02:32','ddd','2022-05-16 16:02:32'),(36,'beforeLunch',23,123,'2022-05-17','22:20','n','ddd','2022-05-17 22:21:26','ddd','2022-05-17 22:21:26'),(37,'afterBreakfast',14,100,'2022-05-18','16:42','n','string151','2022-05-18 15:40:00','string151','2022-05-18 15:40:00'),(38,'afterBreakfast',14,100,'2022-05-18','16:42','n','string151','2022-05-18 15:41:07','string151','2022-05-18 15:41:07'),(39,'afterBreakfast',14,100,'2022-05-18','16:42','n','string151','2022-05-19 00:43:31','string151','2022-05-19 00:43:31'),(40,'afterLunch',33,56,'2022-05-19','13:24','n','hyun55120@gmail.com','2022-05-19 13:24:14','hyun55120@gmail.com','2022-05-19 13:24:14'),(41,'afterBreakfast',33,132,'2022-05-19','13:30','n','hyun55120@gmail.com','2022-05-19 13:31:10','hyun55120@gmail.com','2022-05-19 13:31:10'),(42,'beforeDinner',33,110,'2022-05-19','13:30','n','hyun55120@gmail.com','2022-05-19 13:31:23','hyun55120@gmail.com','2022-05-19 13:31:23'),(43,'afterBreakfast',23,125,'2022-05-19','14:22','n','ddd','2022-05-19 14:23:37','ddd','2022-05-19 14:23:37'),(44,'afterLunch',40,100,'2022-05-19','16:22','y','weclusive@gmail.com','2022-05-19 16:22:48','weclusive@gmail.com','2022-05-19 16:22:48'),(45,'beforeBreakfast',40,110,'2022-05-19','08:22','y','weclusive@gmail.com','2022-05-19 16:24:20','weclusive@gmail.com','2022-05-19 16:24:20'),(46,'beforeBreakfast',40,100,'2022-05-19','08:00','y','weclusive@gmail.com','2022-05-19 16:26:52','weclusive@gmail.com','2022-05-19 16:26:52'),(47,'afterBreakfast',40,120,'2022-05-19','09:30','n','weclusive@gmail.com','2022-05-19 16:27:22','weclusive@gmail.com','2022-05-19 16:27:22'),(48,'beforeBreakfast',40,110,'2022-05-19','08:20','n','weclusive@gmail.com','2022-05-19 16:27:47','weclusive@gmail.com','2022-05-19 16:27:47'),(49,'beforeBreakfast',40,100,'2022-05-18','08:20','n','weclusive@gmail.com','2022-05-19 16:28:15','weclusive@gmail.com','2022-05-19 16:28:15'),(50,'afterBreakfast',40,140,'2022-05-18','09:40','n','weclusive@gmail.com','2022-05-19 16:28:52','weclusive@gmail.com','2022-05-19 16:28:52'),(51,'afterDinner',40,120,'2022-05-18','20:22','n','weclusive@gmail.com','2022-05-19 16:29:16','weclusive@gmail.com','2022-05-19 16:29:16'),(52,'beforeBreakfast',40,95,'2022-05-17','08:31','n','weclusive@gmail.com','2022-05-19 16:32:51','weclusive@gmail.com','2022-05-19 16:32:51'),(53,'afterBreakfast',40,118,'2022-05-17','09:31','n','weclusive@gmail.com','2022-05-19 16:33:18','weclusive@gmail.com','2022-05-19 16:33:18'),(54,'beforeBreakfast',40,100,'2022-05-16','08:00','n','weclusive@gmail.com','2022-05-19 16:34:25','weclusive@gmail.com','2022-05-19 16:34:25'),(55,'afterBreakfast',40,142,'2022-05-16','09:14','n','weclusive@gmail.com','2022-05-19 16:35:43','weclusive@gmail.com','2022-05-19 16:35:43'),(56,'afterLunch',23,80,'2022-05-18','13:25','n','ddd','2022-05-20 01:30:12','ddd','2022-05-20 01:30:12'),(57,'afterBreakfast',23,100,'2022-05-16','16:42','n','ddd','2022-05-20 04:11:22','ddd','2022-05-20 04:11:22'),(58,'beforeBreakfast',23,80,'2022-05-17','16:42','n','ddd','2022-05-20 04:11:39','ddd','2022-05-20 04:11:39'),(59,'beforeBreakfast',23,90,'2022-05-16','16:42','n','ddd','2022-05-20 04:11:46','ddd','2022-05-20 04:11:46'),(60,'beforeBreakfast',23,120,'2022-05-18','16:42','n','ddd','2022-05-20 04:11:51','ddd','2022-05-20 04:11:51'),(61,'beforeBreakfast',23,110,'2022-05-19','16:42','n','ddd','2022-05-20 04:11:55','ddd','2022-05-20 04:11:55'),(62,'beforeBreakfast',23,85,'2022-05-20','07:00','n','ddd','2022-05-20 04:12:01','ddd','2022-05-20 04:12:01'),(63,'beforeBreakfast',23,80,'2022-05-01','09:15','n','ddd','2022-05-20 09:16:46','ddd','2022-05-20 09:16:46'),(64,'beforeBreakfast',23,75,'2022-05-01','09:15','n','ddd','2022-05-20 09:17:20','ddd','2022-05-20 09:17:20'),(65,'beforeBreakfast',23,75,'2022-05-03','09:15','n','ddd','2022-05-20 09:17:37','ddd','2022-05-20 09:17:37'),(66,'beforeBreakfast',23,110,'2022-05-04','09:15','n','ddd','2022-05-20 09:17:50','ddd','2022-05-20 09:17:50'),(67,'beforeBreakfast',23,90,'2022-05-05','09:15','n','ddd','2022-05-20 09:18:04','ddd','2022-05-20 09:18:04'),(68,'beforeBreakfast',23,110,'2022-05-06','09:15','n','ddd','2022-05-20 09:18:19','ddd','2022-05-20 09:18:19'),(69,'beforeBreakfast',23,95,'2022-05-06','09:15','n','ddd','2022-05-20 09:18:28','ddd','2022-05-20 09:18:28'),(70,'beforeBreakfast',23,120,'2022-05-07','09:15','n','ddd','2022-05-20 09:18:47','ddd','2022-05-20 09:18:47'),(71,'breakfast',23,120,'2022-05-14','08:30','n','ddd','2022-05-20 09:43:52','ddd','2022-05-20 09:43:52'),(72,'lunch',23,140,'2022-05-14','12:30','n','ddd','2022-05-20 09:44:05','ddd','2022-05-20 09:44:05'),(73,'dinner',23,135,'2022-05-14','18:30','n','ddd','2022-05-20 09:44:13','ddd','2022-05-20 09:44:13'),(74,'beforeBreakfast',23,99,'2022-05-15','08:00','n','ddd','2022-05-20 09:45:22','ddd','2022-05-20 09:45:22'),(75,'breakfast',23,105,'2022-05-15','08:30','n','ddd','2022-05-20 09:45:32','ddd','2022-05-20 09:45:32'),(76,'beforeDinner',23,103,'2022-05-15','17:30','n','ddd','2022-05-20 09:45:55','ddd','2022-05-20 09:45:55'),(77,'lunch',23,115,'2022-05-15','12:30','n','ddd','2022-05-20 09:46:04','ddd','2022-05-20 09:46:04'),(78,'afterLunch',23,132,'2022-05-15','13:30','n','ddd','2022-05-20 09:46:18','ddd','2022-05-20 09:46:18'),(79,'dinner',23,138,'2022-05-15','18:30','n','ddd','2022-05-20 09:48:48','ddd','2022-05-20 09:48:48'),(80,'afterDinner',23,151,'2022-05-15','20:30','n','ddd','2022-05-20 09:48:58','ddd','2022-05-20 09:48:58'),(81,'afterDinner',23,133,'2022-05-19','20:30','n','ddd','2022-05-20 09:51:45','ddd','2022-05-20 09:51:45'),(82,'beforeDinner',23,112,'2022-05-19','20:30','n','ddd','2022-05-20 09:51:55','ddd','2022-05-20 09:51:55'),(83,'beforeLunch',23,120,'2022-05-19','20:30','n','ddd','2022-05-20 09:52:03','ddd','2022-05-20 09:52:03'),(84,'afterLunch',23,122,'2022-05-19','20:30','n','ddd','2022-05-20 09:52:09','ddd','2022-05-20 09:52:09'),(86,'afterBreakfast',23,95,'2022-05-20','09:30','n','ddd','2022-05-20 09:52:44','ddd','2022-05-20 09:52:44'),(87,'beforeBreakfast',23,92,'2022-05-14','07:30','n','ddd','2022-05-20 10:22:07','ddd','2022-05-20 10:22:07'),(88,'afterBreakfast',23,112,'2022-05-14','09:30','n','ddd','2022-05-20 10:22:19','ddd','2022-05-20 10:22:19'),(89,'beforeLunch',23,104,'2022-05-14','11:30','n','ddd','2022-05-20 10:22:34','ddd','2022-05-20 10:22:34'),(90,'afterLunch',23,127,'2022-05-14','13:30','n','ddd','2022-05-20 10:22:45','ddd','2022-05-20 10:22:45'),(91,'beforeDinner',23,108,'2022-05-14','16:30','n','ddd','2022-05-20 10:23:01','ddd','2022-05-20 10:23:01'),(92,'afterDinner',23,118,'2022-05-14','20:30','n','ddd','2022-05-20 10:23:11','ddd','2022-05-20 10:23:11');
/*!40000 ALTER TABLE `blood_sugar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-20 10:58:00
